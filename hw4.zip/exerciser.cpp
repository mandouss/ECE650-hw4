#include "exerciser.h"

void exercise(connection *C)
{
  add_color(C, "White");
  add_state(C, "CA");
  add_player(C, 16, 30, "Stephen", "Curry", 33, 25, 4, 6, 1.8, 0.2);
  add_team(C, "Davidson", 1, 9, 8, 15);
  cout << "query1_test:" << std::endl;
  query1(C,
	 1, 35, 45,
	 1, 20, 30,
	 0, 1, 4,
	 1, 2, 3,
	 0, 0.0, 10.0,
	 1, 0.0, 10.0);
  cout << std::endl;
  cout << "query2_test:"<< std::endl;
  query2(C, "Orange");
  cout << std::endl;
  cout << "query3_test:"<< std::endl;
  query3(C, "Miami");
  cout << std::endl;
  cout << "query4_test:"<< std::endl;
  //query4(C, "NC", "DarkBlue");
  query4(C, "NC", "Orange");
  cout << std::endl;
  cout << "query5_test:"<< std::endl;
  query5(C, 6);
  cout << std::endl;  
}
